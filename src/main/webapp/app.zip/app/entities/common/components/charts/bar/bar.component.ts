import { Component, OnInit, Input, ElementRef, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import 'anychart';
@Component({
  selector: 'jhi-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.css']
})
export class BarComponent implements OnInit, AfterViewInit {

  // @ViewChild('barchartContainer') container;
  chart: any = null;
  @Input() chartData: any;
  constructor() { }

  ngOnInit() {
    // var chart = anychart.fromJson({
    //   'chart': {
    //     'type': 'bar',
    //     'series':[{
    //       'data': this.chartData,
    //     }],
    //   }
    // });
    // chart.container('bargraph');
    // chart.draw();
  }
  ngAfterViewInit() {
    console.log(this.chartData);
    // const chart  = anychart.bar();
    // const series = chart.bar(athis.chartDat);
    // series.fill('#6698FF .6')
    // series.tooltip().enabled(true).title().enabled(true)
    // series.labels().enabled(true).anchor('left-center').position('right-center').fontSize(13);
    // chart.container('bargraph');
    // chart.draw();
    // this.chartData = [];
    this.chart = anychart.bar();

// create a bar series and set the data
var series = this.chart.bar(this.chartData);

// set the container id
this.chart.container("container");

// initiate drawing the chart
this.chart.draw();
  
  }
}

