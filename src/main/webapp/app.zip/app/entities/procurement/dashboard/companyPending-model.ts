export class PendingLists {
    name: any;
    duns: any;
    totalReq: any;
    lastReq: any;
}
