export class CompanyModel {
    name: any;
    duns: any;
    rating: {
        name: any;
        grade: any;
    };
    paydex: {
        name: any;
        grade: any;
    };
    viability: {
        name: any;
        grade: any;
    };
}
