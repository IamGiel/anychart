import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'anychart';

@Component({
    selector: 'jhi-supplierdata',
    templateUrl: './supplierdata.component.html',
    styleUrls: ['./supplierdata.component.css']
})
export class SupplierdataComponent implements OnInit {
    chartData = [];
    financialdetails = 'More details';
    environmentdetails = 'More details';
    ethicaldetails = 'More details';
    labordetails = 'More details';
    showSubCards: boolean;
    data: any = null;
    columnData = [];
    columnDatas = [];
    ethicaldata = [];
    labourData = [];
    treeData = [];
    showMore = '';
    showEnv = '';
    showEthical = '';
    showLabor = '';
    mapdropdown = "Basic Map";
    mapdrop: boolean;
    ngOnInit() {
        this.chartData = [
            { label: 'Shared', value: 86, fill: '#31d490' },
            { label: 'Pending', value: 12, fill: '#FFCB70' },
            { label: 'Declined', value: 2, fill: '#FF7272' }
        ];
        this.columnData = [
            { label: '2', value: 2, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '2', value: 2, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '3', value: 3, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '4', value: 4, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '5', value: 5, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '6', value: 6, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '7', value: 7, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '8', value: 8, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '9', value: 9, fill: '#E7E7E7', stroke: '#E7E7E7' },
        ];
        this.columnDatas = [
            ['0-29', 3],
            ['30-49', 4],
            ['50-69', 9],
            ['70-89', 9],
            ['90-100', 7]
        ];
        this.ethicaldata = [
            ['0', 6],
            ['1-10', 3],
            ['11-20', 2.8],
            ['21-30', 2],
            ['30+', 1.8]
        ];
        this.labourData = [
            { label: '0-10', value: 5, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '2', value: 4, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '3', value: 3, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '4', value: 3, fill: '#E7E7E7', stroke: '#E7E7E7' },
            { label: '5', value: 2, fill: '#E7E7E7', stroke: '#E7E7E7' },
        ];
        this.treeData = [
            {
                name: 'European Union', children: [
                    { name: 'Belgium', value: 11443830 },
                    { name: 'France', value: 64938716 },
                    { name: 'Germany', value: 80636124 },
                    { name: 'Greece', value: 10892931 },
                    { name: 'Italy', value: 59797978 },
                    { name: 'Netherlands', value: 17032845 },
                    { name: 'Poland', value: 38563573 },
                    { name: 'Romania', value: 19237513 },
                    { name: 'Spain', value: 46070146 },
                    { name: 'United Kingdom', value: 65511098 }
                ]
            }
        ];
    }

    showMapDropDown() {
        this.mapdrop = !this.mapdrop;
    }

    showHideFinancialData() {
        if (this.financialdetails == 'More details') {
            this.showSubCards = true;
            this.financialdetails = 'Hide details';
            this.environmentdetails = 'More details';
            this.showMore = 'show';
            this.showEnv = '';
        } else {
            this.showSubCards = false;
            this.financialdetails = 'More details';
            this.showMore = '';
        }
    }

    selectMap(maptype: string) {
        this.mapdropdown = maptype;
        this.mapdrop = !this.mapdrop;
    }

    showHideEnivornData() {
        if (this.environmentdetails == 'More details') {
            this.showSubCards = true;
            this.environmentdetails = 'Hide details';
            this.financialdetails = 'More details';
            this.showEnv = 'show';
            this.showMore = '';
        } else {
            this.showSubCards = false;
            this.environmentdetails = 'More details';
            this.showEnv = '';
        }
    }

    showHideEthicalData() {
        if (this.ethicaldetails == 'More details') {
            this.showSubCards = true;
            this.ethicaldetails = 'Hide details';
            this.showMore = 'show';
        } else {
            this.showSubCards = false;
            this.ethicaldetails = 'More details';
        }
    }

    showHideLaborData() {
        if (this.labordetails == 'More details') {
            this.showSubCards = true;
            this.labordetails = 'Hide details';
            this.showMore = 'show';
        } else {
            this.showSubCards = false;
            this.labordetails = 'More details';
        }
    }

    constructor(private http: HttpClient) {

    }
}
